	<div class="heading">About</div>
		<ul>
			<li>MyWebSQL is developed and maintained by <a title="Send me an email !" href='mailto:Samnan <samnan_akhoond@yahoo.com>'>Samnan ur Rehman Akhoond</a></li>
			<li>Please use the 'Report a Bug' link to submit your problems. Most of the bugs reported are fixed with new releases of the software</li>
			<li>This program is freeware and comes with no warranties, however, every effort has been made to ensure complete safety of your data. In any case, the author will not be liable for any damage caused to your data by the use of this application.</li>
		</ul>
	</div>
