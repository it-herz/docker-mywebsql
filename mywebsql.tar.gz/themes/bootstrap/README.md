MyWebSQL-Theme-bootstrap
====================

A Twitter bootstrap style theme for MyWebSQL.
Based on the [theme created by Addy Osmani](http://addyosmani.com/blog/jquery-ui-bootstrap/)