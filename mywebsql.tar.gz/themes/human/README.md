MyWebSQL-Theme-human
====================

Ubuntu-ish color theme for MyWebSQL